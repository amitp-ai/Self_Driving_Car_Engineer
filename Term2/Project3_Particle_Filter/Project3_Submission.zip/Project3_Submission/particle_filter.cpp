/*
 * particle_filter.cpp
 *
 *  Created on: Dec 12, 2016
 *      Author: Tiffany Huang
 */

#include <random>
#include <algorithm>
#include <iostream>
#include <numeric>

#include "particle_filter.h"

#include "map.h"

void ParticleFilter::init(double x, double y, double theta, double std[]) {
	// TODO: Set the number of particles. Initialize all particles to first position (based on estimates of
	//   x, y, theta and their uncertainties from GPS) and all weights to 1.
	// Add random Gaussian noise to each particle.
	// NOTE: Consult particle_filter.h for more information about this method (and others in this file).


	//AMIT'S IMPLEMENTAION
	num_particles = 30;

	// noise generation
	std::default_random_engine gen;
	std::normal_distribution<double> N_x_init(0.0, std[0]);
	std::normal_distribution<double> N_y_init(0.0, std[1]);
	std::normal_distribution<double> N_theta_init(0.0, std[2]);

	Particle temp_particle;
	double temp_weight = 1.0;

	for(int i=0; i<num_particles; i++)
    {
        temp_particle.id = i+1;
        temp_particle.weight = temp_weight;

        temp_particle.x = x + N_x_init(gen);
        temp_particle.y = y + N_y_init(gen);
        temp_particle.theta = theta + N_theta_init(gen);

        weights.push_back(temp_weight);
        particles.push_back(temp_particle);
    }

    is_initialized = true;

    return; //void return

}

void ParticleFilter::prediction(double delta_t, double std_pos[], double velocity, double yaw_rate) {
	// TODO: Add measurements to each particle and add random Gaussian noise.
	// NOTE: When adding noise you may find std::normal_distribution and std::default_random_engine useful.
	//  http://en.cppreference.com/w/cpp/numeric/random/normal_distribution
	//  http://www.cplusplus.com/reference/random/default_random_engine/


	//AMIT'S IMPLEMENTAION
	//noise generation
	//Ideally, we'd add noise to the control variables directly i.e. velocity and yaw_rate
	//However, since we don't have their variance info., we will just use them deterministically
	//and add noise to the final position and heading
    std::default_random_engine gen;
	std::normal_distribution<double> N_x(0.0, std_pos[0]);
	std::normal_distribution<double> N_y(0.0, std_pos[1]);
	std::normal_distribution<double> N_theta(0.0, std_pos[2]);

	//motion model
	double xx, yy, tht;
    for(int i=0; i<num_particles; i++)
    {
        xx = particles[i].x;
        yy = particles[i].y;
        tht = particles[i].theta;

        if(fabs(yaw_rate) < 0.001)
        {
            xx = xx + velocity*delta_t*cos(tht);
            yy = yy + velocity*delta_t*sin(tht);
            tht = tht;
        }

        else
        {
            xx = xx + velocity/yaw_rate * (sin(tht+yaw_rate*delta_t) - sin(tht));
            yy = yy + velocity/yaw_rate * (-cos(tht+yaw_rate*delta_t) + cos(tht));
            tht = tht + yaw_rate*delta_t;
        }

        //add noise
        xx = xx + N_x(gen);
        yy = yy + N_y(gen);
        tht = tht + N_theta(gen);

        //normalize the angle
        tht = fmod(tht, 2.0 * M_PI);

        particles[i].x = xx;
        particles[i].y = yy;
        particles[i].theta = tht;

        //std::cout << fmod(-400,2*180) << std::endl;

    }

}

void ParticleFilter::dataAssociation(std::vector<LandmarkObs> predicted, std::vector<LandmarkObs>& observations) {
	// TODO: Find the predicted measurement that is closest to each observed measurement and assign the
	//   observed measurement to this particular landmark.
	// NOTE: this method will NOT be called by the grading code. But you will probably find it useful to
	//   implement this method and use it as a helper during the updateWeights phase.


	//AMIT'S IMPLEMENTATION
    //The observations are in the car's (i.e. each particle's) coordinate system
    //Need to first transform it to the map's coordinate system
    double xo, yo;

    //transform all the observations to map's coordinate system
    for(unsigned int jj=0; jj<observations.size(); jj++)
    {
        //observations in maps' coordinate system
        xo = observations[jj].x;
        yo = observations[jj].y;

        //Nearest Neighbor
        //find the closest landmark association using nearest neighbor for each observation
        double min_dist = 1e10; //some large number
        double curr_dist;
        LandmarkObs temp_landmark, matched_landmark;

        for(unsigned int ll=0; ll<predicted.size(); ll++)
        {
            temp_landmark = predicted[ll];
            curr_dist = dist(xo,yo,temp_landmark.x,temp_landmark.y);

            if( curr_dist < min_dist)
            {
                min_dist = curr_dist;
                matched_landmark = temp_landmark;
            }
        }

        observations[jj].id = matched_landmark.id; //note: landmark id is indexed from 1 and not 0
        observations[jj].x = observations[jj].x - matched_landmark.x;
        observations[jj].y = observations[jj].y - matched_landmark.y;
    }

}

void ParticleFilter::updateWeights(double sensor_range, double std_landmark[],
		std::vector<LandmarkObs> observations, Map map_landmarks) {
	// TODO: Update the weights of each particle using a mult-variate Gaussian distribution. You can read
	//   more about this distribution here: https://en.wikipedia.org/wiki/Multivariate_normal_distribution
	// NOTE: The observations are given in the VEHICLE'S coordinate system. Your particles are located
	//   according to the MAP'S coordinate system. You will need to transform between the two systems.
	//   Keep in mind that this transformation requires both rotation AND translation (but no scaling).
	//   The following is a good resource for the theory:
	//   https://www.willamette.edu/~gorr/classes/GeneralGraphics/Transforms/transforms2d.htm
	//   and the following is a good resource for the actual equation to implement (look at equation
	//   3.33. Note that you'll need to switch the minus sign in that equation to a plus to account
	//   for the fact that the map's y-axis actually points downwards.)
	//   http://planning.cs.uiuc.edu/node99.html


	//AMIT'S IMPLEMENTAION
    double xp, yp, tht_p;
    double sigma_x = std_landmark[0];
    double sigma_y = std_landmark[1];
    double x_diff, y_diff;

    //make sure all the weights are 1 (resampling process should do it)
    for(int i=0; i<num_particles; i++)
    {
        xp = particles[i].x;
        yp = particles[i].y;
        tht_p = particles[i].theta;

        //find the landmarks within sensor range of the car/particle
        //so as don't have to search all the landmarks for all the observations to find correspondence
        //this will be faster
        std::vector<LandmarkObs> landmarks_within_range;
        for(unsigned int lm=0; lm<map_landmarks.landmark_list.size(); lm++)
        {
            LandmarkObs temp_lm;

            temp_lm.id = map_landmarks.landmark_list[lm].id_i;
            temp_lm.x = map_landmarks.landmark_list[lm].x_f;
            temp_lm.y = map_landmarks.landmark_list[lm].y_f;

            if(dist(xp,yp,temp_lm.x,temp_lm.y) < sensor_range)
            {
                landmarks_within_range.push_back(temp_lm);
            }
        }

        //std::cout << "\n" << landmarks_within_range.size() << " versus " << map_landmarks.landmark_list.size() << "\n";

        std::vector<LandmarkObs> observations_pred = observations;
        double t_xo, t_yo, xo, yo;
        //transform all the observations to map's coordinate system
        for(unsigned int jj=0; jj<observations_pred.size(); jj++)
        {
            //observations in car/particles coordinate system
            xo = observations_pred[jj].x;
            yo = observations_pred[jj].y;

            //observations in map's coordinate system
            t_xo = xo * cos(tht_p) - yo * sin(tht_p) + xp;
            t_yo = xo * sin(tht_p) + yo * cos(tht_p) + yp;

            observations_pred[jj].x = t_xo;
            observations_pred[jj].y = t_yo;
        }

        dataAssociation(landmarks_within_range, observations_pred); //observations_pred will be modified here

        for(unsigned int jj=0; jj<observations_pred.size(); jj++)
        {
            //Calculate the probabilities
            //observations_pred has the distance between the measurement and associated landmark in it
            x_diff = observations_pred[jj].x; //distance between measurement and associated landmark in x direction
            y_diff = observations_pred[jj].y; //distance between measurement and associated landmark in y direction
            weights[i] *= 1/(2*sigma_x*sigma_y) * exp(-((x_diff)*(x_diff)/(2*sigma_x*sigma_x)
                                                        + (y_diff)*(y_diff)/(2*sigma_y*sigma_y)));
        }

        particles[i].weight = weights[i];
    }

}


void ParticleFilter::resample() {
	// TODO: Resample particles with replacement with probability proportional to their weight.
	// NOTE: You may find std::discrete_distribution helpful here.
	//   http://en.cppreference.com/w/cpp/numeric/random/discrete_distribution


	//AMIT'S IMPLEMENTATION
    std::default_random_engine gen;
    std::discrete_distribution<int> resampler(weights.begin(), weights.end());
    //resampler will generate a random number between 0 and weights.size()-1 weighted according to variable weights

    std::vector <Particle> new_particles;
    std::vector<double> new_weights;
    int idx;

    for(int i=0; i<weights.size(); i++)
    {
        idx = resampler(gen);
        //don't update the id of the particle that was given during initialization
        new_particles.push_back(particles[idx]);
        new_weights.push_back(1.0); //make all weights be 1
    }

    particles = new_particles;
    weights = new_weights;

    ///test discrete distribution
    /*
    std::vector< double> weights(5);
    weights[0] = 0.1;
    weights[1] = 0.1;
    weights[2] = 0.5;
    weights[3] = 0.1;
    weights[4] = 0.4;

    std::default_random_engine generator;
    std::discrete_distribution<int> distribution(weights.begin(),weights.end()); //{2,2,2,2,2}); //weights.begin(), weights.end()) ;

    int prob[5]={};

    for ( int i=0; i<500; ++i) {
      int number = distribution( generator);
      cout << number << endl;
      ++prob[number];
    }

    cout << endl;
    for ( int i=0; i<5; ++i) {
      cout << prob[i] << endl;
    }
    */

}

void ParticleFilter::write(std::string filename) {
	// You don't need to modify this file.
	std::ofstream dataFile;
	dataFile.open(filename, std::ios::app);
	for (int i = 0; i < num_particles; ++i) {
		dataFile << particles[i].x << " " << particles[i].y << " " << particles[i].theta << "\n";
	}
	dataFile.close();
}
